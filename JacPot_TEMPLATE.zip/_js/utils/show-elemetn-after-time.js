/**
 *
 * @param element {HTMLElement}
 * @param timeInMilliseconds {number}
 */
export const showErrorMessages = (element, timeInMilliseconds) => {
    element.style.display = 'flex'

    setTimeout(() => {
        element.style.display = 'none'
    }, timeInMilliseconds || 5000)
}

/**
 *
 * @param element {HTMLElement}
 * @param timeInMilliseconds {number}
 */
export const showInputsError = (() => {
    let timeout = null;

    return function (element, timeInMilliseconds = 4000) {
        if (timeout) clearTimeout(timeout);

        element.style.opacity = "1";
        element.style.pointerEvents = "all";

        timeout = setTimeout(() => {
            element.style.opacity = "0";
            element.style.pointerEvents = "none";
        }, timeInMilliseconds);
    };
})();