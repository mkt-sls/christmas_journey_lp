import {ERROR_INPUTS_MESSAGES} from "../enums/form-errors.js";

/**
 * @param {Object} formState
 * @param {HTMLDivElement} errorEmail
 * @param {HTMLDivElement} errorPassword
 * @param {HTMLDivElement} errorTerms
 * @param {string} activeLang
 * @returns {boolean}
 */
export const validateRegisterForm = ({formState, errorEmail, errorPassword, errorTerms, activeLang}) => {
    let _isValid = true

    if (!formState.email) {
        _isValid = false
        errorEmail.parentElement.classList.add("active")
        errorEmail.textContent = ERROR_INPUTS_MESSAGES[activeLang]["requiredField"]
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(formState.email)) {
        errorEmail.parentElement.classList.add("active")
        errorEmail.textContent = ERROR_INPUTS_MESSAGES[activeLang]["mailExample"]

        console.log(formState.email)

        _isValid = false
    }

    if (!formState.password) {
        _isValid = false
        errorPassword.parentElement.classList.add("active")
        errorPassword.textContent = ERROR_INPUTS_MESSAGES[activeLang]["requiredField"]
    } else if (formState.password.length < 8) {
        _isValid = false
        errorPassword.parentElement.classList.add("active")
        errorPassword.textContent = ERROR_INPUTS_MESSAGES[activeLang]["passwordMinLength"]
    }

    if (!formState.terms) {
        _isValid = false
        errorTerms.parentElement.classList.add("active")
        errorTerms.textContent = ERROR_INPUTS_MESSAGES[activeLang]["termsConfirm"]
    }

     return _isValid
}