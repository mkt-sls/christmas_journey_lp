/**
 * @param {string} duration — строка формата "10s 5m 2h 1d"
 */
export const expireDate = (duration) => {
    const dateTimeElements = document.querySelectorAll('.expire-item .expire-time');
    if (dateTimeElements.length < 3) return;

    // Парсим строку в миллисекунды
    const parseDuration = (str) => {
        const regex = /(\d+)([smhd])/g;
        let totalMs = 0;
        let match;

        while ((match = regex.exec(str)) !== null) {
            const value = parseInt(match[1], 10);
            const unit = match[2];

            switch (unit) {
                case "s":
                    totalMs += value * 1000;
                    break;
                case "m":
                    totalMs += value * 60 * 1000;
                    break;
                case "h":
                    totalMs += value * 60 * 60 * 1000;
                    break;
                case "d":
                    totalMs += value * 24 * 60 * 60 * 1000;
                    break;
            }
        }
        return totalMs;
    };

    let remaining = parseDuration(duration);

    const updateCountdown = () => {
        if (remaining <= 0) {
            dateTimeElements[0].textContent = "0"; // секунды
            dateTimeElements[1].textContent = "0"; // минуты
            dateTimeElements[2].textContent = "0"; // часы
            clearInterval(timer);
            return;
        }

        const hours = Math.floor(remaining / (1000 * 60 * 60));
        const minutes = Math.floor((remaining / (1000 * 60)) % 60);
        const seconds = Math.floor((remaining / 1000) % 60);

        dateTimeElements[2].textContent = seconds;
        dateTimeElements[1].textContent = minutes;
        dateTimeElements[0].textContent = hours;

        remaining -= 1000;
    };

    updateCountdown();
    const timer = setInterval(updateCountdown, 1000); // обновляем каждую секунду
};
