/**
 * @param login {string}
 * @param password {string}
 */
export const downloadLoginAndPasswordFile = (login, password) => {
    try {
        const content = `login: ${login}\npassword: ${password}`;
        const blob = new Blob([content], {type: 'text/plain'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');

        a.href = url;
        a.download = 'login-and-password.txt';
        a.click();
        URL.revokeObjectURL(url);
    } catch (error) {
        console.log("Error downloading file:", error);
    }
}
