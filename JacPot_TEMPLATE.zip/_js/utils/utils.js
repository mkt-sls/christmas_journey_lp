import {COUNTRY} from "../enums/countries.js";

export const formatCountryName = (country) => {
    return country.replace(/([a-z])([A-Z])/g, '$1 $2');
}

export const getCountryNameByCode = (countryCode) => {
    return Object.entries(COUNTRY).find(([key, country]) => country.codeName === countryCode)[0];
}

/**
 * @param str
 * @returns {string|null}
 */
export const getTextInsideParentheses = (str) => {
    const matches = str.match(/\(([^)]+)\)/);
    return matches ? matches[1] : null;
}