/**
 * @param inputField {EventTarget<HTMLInputElement>}
 * @param formState {Object}
 */
export const formatPhoneNum = (inputField, formState) => {
    try {
        let value = inputField.value;
        let filteredValue = value.replace(/[^0-9]/g, '');

        if (filteredValue.length > formState.phoneConfig.maxNumberLength) {
            filteredValue = filteredValue.slice(0, formState.phoneConfig.maxNumberLength);
        }

        function formatNumber(phoneNumber) {
            phoneNumber = phoneNumber.replace(/\D/g, '');
            phoneNumber = phoneNumber.replace(/(\d{3})(?=\d)/, '$1-');
            phoneNumber = phoneNumber.replace(/(\d{3}-\d{3})(?=\d)/, '$1-');
            return phoneNumber;
        }

        let cursorPosition = inputField.selectionStart;
        let resultNumber = formatNumber(filteredValue);

        inputField.value = resultNumber;
        formState.phone = resultNumber;

        const cursorNewPosition = cursorPosition === 8 ? cursorPosition + 1 : cursorPosition === 4 ? cursorPosition + 2 : cursorPosition

        inputField.setSelectionRange(cursorNewPosition, cursorNewPosition);
    } catch (error) {
        console.error('Error in formatPhoneNum:', error)
    }
};

function renderPhoneNewCountry(county) {
    try {
        const {codeName, code} = county
        // console.log(county);
        registerFormState.countryCode = code
        countryName.textContent = codeName + ' ' + code;
        dropCountyCode.textContent = code;
        countryDropDownImages.forEach((image) => {
            image.src = `./assets/images/flags/${codeName}.svg`
        });
    } catch (error) {
        console.error('Error in renderPhoneNewCountry:', error)
    }
}