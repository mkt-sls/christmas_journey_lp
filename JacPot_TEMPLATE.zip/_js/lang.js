import {LANG_TEXTS} from "./enums/form-text.js";
import {expireDate} from "./utils/expire-date.js";

const locationOrigin = window.location.origin
const isDevelopmentOnConstructor = locationOrigin.includes("https://land-crm")
const isDevelopment = isDevelopmentOnConstructor || window.location.hostname === "localhost";

let _lang = null

function landingSetLang() {
    const dataLangElements = document.querySelectorAll('[data-text]');
    const dataPlaceholderElements = document.querySelectorAll('[data-placeholder]');

    const langItems = document.querySelectorAll(".lang-list button");

    //  --------------------------------------------------------------------------


    langItems.forEach((element) => {
        element.addEventListener("click", () => setDropDownLang(element));
    });


    function setDropDownLang(element) {
        const langCode = element.textContent?.trim() || "";


        if (langCode) {
            langItems.forEach((item) => item.classList.remove("active"));
            element.classList.toggle("active");

            setLang(langCode);
        }
    }

//  ----------------------------------------------------------------------------

    function setLang(language) {
        _lang = language

        dataLangElements.forEach((element) => {
            const langText = element.dataset.text
            element.textContent = LANG_TEXTS[language][langText || ""] || "";
        })

        dataPlaceholderElements.forEach((element) => {
            const langPlaceholder = element.dataset.placeholder

            element.placeholder = LANG_TEXTS[language][langPlaceholder || ""] || "";
        })

        setContainerChildrenActiveLang(".form__head-content-wrap", language.toLowerCase());

    }

    setDropDownLang(langItems[0])
}

function setContainerChildrenActiveLang(containerSelector, language) {
    const containerLanguagesContent = document.querySelector(containerSelector);

    if (!containerLanguagesContent) {
        console.log("This container doesn't exist " + containerSelector || "");
        return;
    }

    const containerLanguagesContentChildren = [
        ...containerLanguagesContent.children,
    ];

    containerLanguagesContent?.classList.forEach((cl) => {
        if (cl !== containerSelector.replace(".", "")) {
            containerLanguagesContent.classList.remove(cl);
        }
    });
    containerLanguagesContent?.classList.add(language);

    containerLanguagesContentChildren.forEach((child) => {
        if (!child.classList.contains(language)) {
            child.style.display = "none";
        } else {
            if (child.classList.contains("popup")) {
                child.style.display = "flex";
            } else {
                child.style.display = "contents";
            }
        }
    });
}

const formClose = document.querySelector(".modal-register-close");

formClose?.addEventListener("click", () => {
    document.querySelector(".modal-wrap-register").classList.remove("active");
})

const initExpireDate = () => {
    const {offerExpireDateAndTimeUTC} = Object.values(LANG_TEXTS)[0]
    expireDate(offerExpireDateAndTimeUTC)
}

if (isDevelopment) {
    setTimeout(() => {
        landingSetLang()
        initExpireDate()
    }, 1000)
} else {
    landingSetLang()
    initExpireDate()
}