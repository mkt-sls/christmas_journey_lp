import {ERROR_INPUTS_MESSAGES} from "./enums/form-errors.js";
import {TEMP_CONFIG} from "./enums/enums.js";
import {API_HEADERS} from "./enums/api.js";

import {addParamsToUrl, getQueryParams, getURLParams,} from "./utils/url.js";
import {injectAnalytics} from "./analytics.js";
import {executeRecaptcha} from "./api/resilve-recaptcha.js";
import {validateRegisterForm} from "./utils/form-validations.js";

const locationOrigin = window.location.origin;
const isDevelopment =
    locationOrigin.includes("https://land-crm") ||
    window.location.hostname === "localhost" ||
    window.location.hostname === "127.0.0.1";

if (isDevelopment) {
    setTimeout(() => landingMainJsCode(), 1000);
} else {
    landingMainJsCode();
}

async function landingMainJsCode() {
    const langItems = document.querySelectorAll(".lang-list button");
    const formEmailInput = document.querySelector(".form-fast-email input");
    const formEmailFirstStep = document.querySelector(".form-fast-email");

    const formRegister = document.querySelector(".form-register")
    const regEmailInput = document.querySelector(".input-email");
    const regPasswordInput = document.querySelector(".input-password");
    const termsBlock = document.querySelector(".terms-wrap");
    const submitBtn = document.querySelector(".form-register-submit");

    const showPasswordBtn = document.querySelector(".show-password-btn");

    const siteRules = document.querySelector(".terms-link");
    const sitePolicy = document.querySelector(".policy-link");
    const siteLogin = document.querySelector(".login-text a");

    const modalWrapError = document.querySelector(".modal__wrap");

    const errorEmail = document.querySelector(".error-email span");
    const errorPassword = document.querySelector(".error-password span");
    const errorTerms = document.querySelector(".error-terms span");

    const ssoForm = document.querySelector("#sso");
    const ssoFormTmpToken = document.querySelector("#sso-tmpToken");
    const ssoFormRedirect = document.querySelector("#sso-redirect");

    const registerFormState = {
        loading: false,
        landing_id: null,
        _activeLang: langItems[0]?.textContent || "",
        email: "",
        password: "",
        terms: true,
        domain: null,
        ipAddress: ""
    };

    langItems.forEach((element) => {
        element.addEventListener("click", () => (registerFormState._activeLang = element.textContent))
    });

    // ---------------------------------------------

    function setFormModalActiveLangOffer(lang) {
        const langOfferImg = document.querySelector(`.form__head-content.${lang} img`);
        const fomLangOfferImg = document.querySelector(`.form-active-lang-offer`);
        const formWrap = document.querySelector(`.modal-wrap-register`);

        formWrap.classList.add('active')

        if (langOfferImg && fomLangOfferImg) {
            fomLangOfferImg.src = langOfferImg.src;
        }
    }

    formEmailFirstStep.addEventListener("submit", (event) => {
        event.preventDefault();
        registerFormState.email = formEmailInput.value || "";

        if (registerFormState._activeLang) {
            setFormModalActiveLangOffer(registerFormState._activeLang.toLowerCase().trim())
            formRegister.classList.add("active")
            regEmailInput.value = formEmailInput.value || "";
        }
    });

    showPasswordBtn.addEventListener('click', () => {
        regPasswordInput.type = regPasswordInput.type === 'password' ? 'text' : 'password';
    })

    // ---------------------------------------------

    if (isDevelopment) {
        initData(TEMP_CONFIG);
    } else {
        try {
            fetch("config.json")
                .then((res) => res.json())
                .then((data) => initData(data))
                .catch((err) => console.error("Error to get config", err));
        } catch (error) {
            console.error("Error in main fetch block:", error);
        }
    }

    function initData(data) {
        registerFormState.landing_id = data.id;
        registerFormState.email_registration = data.email_registration || null;
        try {
            fetch(data.landing, {
                method: "GET",
                headers: API_HEADERS,
            })
                .then((res) => res.json())
                .then((resData) => {
                    const {data} = resData;

                    injectAnalytics(data, isDevelopment);

                    if (!data.active) {
                        console.log({status: "landing is not active"});
                        const modalLandActive = document.querySelector(".disabled-modal");
                        modalLandActive?.classList.add("active");

                        setTimeout(() => {
                            const mailLink = document.querySelector(".mail-link");
                            mailLink.href = "mailto:support@jack-pot.com";
                            mailLink.textContent = "support@jack-pot.com";
                        }, 50);

                        return;
                    }
                    console.log({status: "landing is active"});

                    registerFormState.ladingData = data

                    registerFormState.recaptcha_key = data.recaptcha_key;

                    const recaptchaScript = document.createElement("script");
                    recaptchaScript.src =
                        "https://www.google.com/recaptcha/api.js?render=" +
                        registerFormState.recaptcha_key;
                    document.body.appendChild(recaptchaScript);

                    registerFormState.country = data.country
                    registerFormState.currency = data.currency

                    const landParams = getQueryParams();

                    const domain = new URL(data.rules)
                    registerFormState.domain = "https://" + domain.hostname

                    siteRules.href = data.rules
                        ? addParamsToUrl(data.rules, landParams)
                        : addParamsToUrl(siteRules.href, landParams);
                    sitePolicy.href = data.policy
                        ? addParamsToUrl(data.policy, landParams)
                        : addParamsToUrl(sitePolicy.href, landParams);
                    siteLogin.href = data.login
                        ? addParamsToUrl(data.login, landParams)
                        : addParamsToUrl(siteLogin.href, landParams);
                })
                .catch((err) => console.error("Error to get landing data", err));
        } catch (error) {
            console.error("Error in nested fetch:", error);
        }
    }

    fetch("https://api.ipify.org?format=json")
        .then((response) => response.json())
        .then((data) => {
            registerFormState.ipAddress = data.ip;
            console.log({ip: data.ip})
        })
        .catch((error) => {
            console.error("Ошибка при получении IP-адреса пользователя:", error);
        });

    regEmailInput.addEventListener("input", () => {
        errorEmail.parentElement.classList.remove("active");
        registerFormState.email = regEmailInput.value || "";
    });
    regPasswordInput.addEventListener("input", () => {
        errorPassword.parentElement.classList.remove("active");
        registerFormState.password = regPasswordInput.value || "";
    });
    termsBlock.addEventListener("click", () => {
        errorTerms.parentElement.classList.remove("active");
        registerFormState.terms = !registerFormState.terms;
        termsBlock.classList.toggle("active");
    });

    formRegister.addEventListener("submit", (event) => {
        event.preventDefault();


        const {
            email,
            password,
            promocode,
            landing_id,
            ladingData,
        } = registerFormState;

        const params = getURLParams()

        const data = {
            email,
            password,
            landing_id,
            language: (registerFormState._activeLang || 'en').toLowerCase(),
            currency: registerFormState.ladingData.currency || null,
            country: registerFormState.ladingData.country || null,
            promocode: registerFormState.ladingData.promocode || null,
            receivePromos: true,
            clientIp: registerFormState.ipAddress,
            ...params
        };

        // ...getURLParams()

        const isValid = validateRegisterForm({
            formState: registerFormState,
            errorEmail,
            errorPassword,
            errorTerms,
            activeLang: registerFormState._activeLang
        })

        if (isValid) {
            executeRecaptcha({
                recaptchaKey: registerFormState.recaptcha_key,
                data,
                onSuccess: () => {
                    register()
                },
                onError: () => modalWrapError.classList.add("active")
            })
        }

        function register() {
            try {
                submitBtn.disabled = true;

                fetch(registerFormState.email_registration, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(data),
                })
                    .then(async (res) => {
                        if (!res.ok) {
                            const dataError = await res.json();
                            throw new Error(dataError.errors[0]);
                        }

                        return res.json();
                    })
                    .then((response) => {
                        const {accessToken} = response.data;
                        const domain = registerFormState.domain;

                        const landParams = getQueryParams();

                        const redirectLang = (registerFormState._activeLang || 'en').toLowerCase()

                        if (domain && accessToken) {
                            const redirectDomain = domain + `/${redirectLang}/` + registerFormState.ladingData.redirect_link

                            ssoForm.action = `${domain}/api/welcome`;
                            ssoFormTmpToken.value = accessToken;
                            ssoFormRedirect.value = addParamsToUrl(redirectDomain, landParams) || "/";
                            ssoForm.submit();
                        }
                    })
                    .catch((err) => {
                        console.log("Произошла ошибка при отправке формы", err);

                        let errorText = ""

                        errorEmail.parentElement.classList.add("active");

                        if (err.message === "reCAPTCHA verification failed. Please try again.") {
                            modalWrapError.classList.add("active");
                            errorText = "reCAPTCHA verification failed."
                        } else if (err.message === "Email already registered. Please use a different email or login.") {
                            // errorText =
                        }

                        errorEmail.textContent = errorText || `${err.message}`
                    })
                    .finally(() => {
                        submitBtn.disabled = false;
                    });
            } catch (error) {
                console.error("Error in register function:", error);
                formSubmitBtn.disabled = false;
            }
        }
    });
}
